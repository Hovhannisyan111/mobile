package com.example.petros_sofi;

import android.database.Cursor;
import android.os.Bundle;
import android.view.*;
import android.widget.*;

import androidx.fragment.app.Fragment;

public class Fragment_2 extends Fragment {

    TextView tv;
    Button read;
    EditText input;
    DatabaseHelper dbHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_2, container, false);

        tv = view.findViewById(R.id.tv);
        read = view.findViewById(R.id.read);
        input = view.findViewById(R.id.input);

        dbHelper = new DatabaseHelper(getActivity());

        read.setOnClickListener(v -> {

            String letter = input.getText().toString();

            Cursor cursor = dbHelper.getPersonsByLetter(letter);

            StringBuilder result = new StringBuilder();

            while (cursor.moveToNext()) {
                String name = cursor.getString(1);
                String surname = cursor.getString(2);
                String phone = cursor.getString(3);

                result.append(name)
                        .append(" ")
                        .append(surname)
                        .append(" - ")
                        .append(phone)
                        .append("\n");
            }

            if (result.length() == 0) {
                tv.setText("No results");
            } else {
                tv.setText(result.toString());
            }

            cursor.close();
        });

        return view;
    }
}
