package com.example.petros_sofi;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "PersonDB";
    private static final int DB_VERSION = 1;

    private static final String TABLE_NAME = "persons";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("CREATE TABLE persons (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "surname TEXT," +
                "phone TEXT)");

        // Insert 5 rows
        db.execSQL("INSERT INTO persons(name,surname,phone) VALUES('Ara','Hakobyan','111')");
        db.execSQL("INSERT INTO persons(name,surname,phone) VALUES('Anna','Sargsyan','222')");
        db.execSQL("INSERT INTO persons(name,surname,phone) VALUES('Ani','Karapetyan','333')");
        db.execSQL("INSERT INTO persons(name,surname,phone) VALUES('David','Petrosyan','444')");
        db.execSQL("INSERT INTO persons(name,surname,phone) VALUES('Diana','Avetisyan','555')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS persons");
        onCreate(db);
    }

    public Cursor getPersonsByLetter(String letter) {
        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM persons WHERE name LIKE ?",
                new String[]{letter + "%"}
        );
    }
}
