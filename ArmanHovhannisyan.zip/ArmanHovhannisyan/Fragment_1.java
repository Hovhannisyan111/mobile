package com.example.petros_sofi;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.*;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

public class Fragment_1 extends Fragment {

    DatabaseHelper dbHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_1, container, false);

        dbHelper = new DatabaseHelper(getActivity());

        // This will create DB and insert data
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Toast.makeText(getActivity(), "Database Created with 5 records", Toast.LENGTH_SHORT).show();

        return view;
    }
}
